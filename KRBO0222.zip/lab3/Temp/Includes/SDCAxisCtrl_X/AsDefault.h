#ifndef _SDCAXISCTRL_X_DEFAULT_2023814118
#define _SDCAXISCTRL_X_DEFAULT_2023814118
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <variablesVAR.h>
#endif
