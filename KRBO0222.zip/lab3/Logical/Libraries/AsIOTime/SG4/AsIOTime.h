/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _ASIOTIME_
#define _ASIOTIME_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif



/* Prototyping of functions and function blocks */
_BUR_PUBLIC signed long AsIOTimeStamp(void);
_BUR_PUBLIC signed long AsIOTimeCyclicStart(void);


#ifdef __cplusplus
};
#endif
#endif /* _ASIOTIME_ */

